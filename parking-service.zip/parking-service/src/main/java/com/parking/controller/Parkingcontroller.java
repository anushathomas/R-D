package com.parking.controller;


import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;

import com.parking.CustomerDetails;


public class Parkingcontroller {
	
	final int size = 160;
	TreeMap<Integer,CustomerDetails> parkingMap = new TreeMap<Integer,CustomerDetails>();  
	SortedSet<Integer> available = new TreeSet<Integer>();
	SortedSet<Integer> filled = new TreeSet<Integer>();
	
	public Parkingcontroller() {
		for(int index=1;index<161; index++) {
			available.add(index);
		}
	}
	
	public void addCar(CustomerDetails cust) {
		
		if(parkingMap.size()>=160) {
			throw new RuntimeException("Parking Full");
		}
		int key = available.first();
		parkingMap.put(key, cust);
		available.remove(key);
		filled.add(key);
		cust = findSlot(key, cust);
	}
	
	public TreeMap<Integer, CustomerDetails> retrieveCars() {
		return parkingMap;
	}
	
	public CustomerDetails findSlot(int index, CustomerDetails c)
	{
		int count = 1;
		while(count< 5) {	
		if(index>=1*count && index<=40*count)
		{
			c.setFloor(count);
			if(index< (40*(count-1) + 11))
			{
				c.setSection(1);
				c.setCompartment(index%10);
				return c;
			}
			else if(index < (40*(count-1) + 21))
			{
				c.setSection(2);
				c.setCompartment(index%10);
				return c;
			}
			else if(index < (40*(count-1) + 31))
			{
				c.setSection(3);
				c.setCompartment(index%10);
				return c;
			}
			else
			{
				c.setSection(4);
				c.setCompartment(index%10);
				return c;
			}
		}
		count++;
		}
		throw new RuntimeException("Invalid Key");
	}
	
	
	public static void main(String[] args)
	{
		Parkingcontroller p = new Parkingcontroller();
		CustomerDetails c1 = new CustomerDetails("Anu", "1234", "10:10");
		p.addCar(c1);
		CustomerDetails c2 = new CustomerDetails("Nitin", "132", "11:11");
		p.addCar(c2);
		CustomerDetails c3 = new CustomerDetails("Yash", "1321", "10:10");
		p.addCar(c3);
		
		System.out.println("The Cars parked are\n"+p.retrieveCars());


}	
}
