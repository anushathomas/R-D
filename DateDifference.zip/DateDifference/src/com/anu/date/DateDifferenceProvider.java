package com.anu.date;


public class DateDifferenceProvider {
	
	 static final int JAN_DAYS=31;
	   static final int FEB_DAYS=28;
	   static final int MAR_DATE=31;
	   static final int APRIL_DAYS=30;
	   static final int MAY_DAYS=31;
	   static final int JUNE_DAYS=30;
	   static final int JULY_DAYS=31;
	   static final int AUGUST_DAYS=31;
	   static final int SEPTEMBER_DAYS=30;
	   static final int OCTOBER_DAYS=31;
	   static final int NOVEMBER_DAYS=30;
	   static final int DECEMBER_DAYS=31;
	   
	   static int[] yearMonths= {
			   0,
			   JAN_DAYS,
			   FEB_DAYS,
			   MAR_DATE,
			   APRIL_DAYS,
			   MAY_DAYS,
			   JUNE_DAYS,
			   JULY_DAYS,
			   AUGUST_DAYS,
			   SEPTEMBER_DAYS,
			   OCTOBER_DAYS,
			   NOVEMBER_DAYS,
			   DECEMBER_DAYS
	   };

		public static long getDateDifference(MyDate startDate, MyDate endDate)
		{
			if(sameDay(startDate, endDate)&&sameMonth(startDate, endDate)&&sameYear(startDate, endDate))
			{
				return 0;
			}
			else if(!sameDay(startDate, endDate)&&sameMonth(startDate, endDate)&&sameYear(startDate, endDate))
			{
				return RemainingDays(startDate, endDate);
			}
			else if(!sameDay(startDate, endDate)&&!sameMonth(startDate, endDate)&&sameYear(startDate, endDate))
			{
				return RemainingDays(startDate, endDate)+RemainingMonthsSameYear(startDate, endDate);
			}
			else if(sameDay(startDate, endDate)&&!sameMonth(startDate, endDate)&&sameYear(startDate, endDate))
			{
				return RemainingDays(startDate, endDate)+RemainingMonthsSameYear(startDate, endDate);
			}
			else if(!sameDay(startDate, endDate)&&!sameMonth(startDate, endDate)&&!sameYear(startDate, endDate))
			{
				if(endDate.getYyyy()-startDate.getYyyy()>=2)
				{
					return RemainingDays(startDate, endDate)+remainingMonthsDifferentYears(startDate, endDate)+intermYearDays(startDate, endDate); 
				}
				else
				return RemainingDays(startDate, endDate)+remainingMonthsDifferentYears(startDate, endDate);
			}
			else
			{
				return 1;
			}
		}
		
		
		
		
		
		private static boolean sameDay(MyDate startDate, MyDate endDate)
		{
			if(startDate.getDd()==endDate.getDd())
				return true;
			else
				return false;
		}
		private static boolean sameMonth(MyDate startDate, MyDate endDate)
		{
			if(startDate.getMm()==endDate.getMm())
				return true;
			else
				return false;
		}
		private static boolean sameYear(MyDate startDate, MyDate endDate)
		{
			if(startDate.getYyyy()==endDate.getYyyy())
				return true;
			else
				return false;
		}
		
		
		private static int RemainingDays(MyDate startDate,MyDate endDate)
		{
			int bonusDay=0;
			if(startDate.getMm()==2)
				bonusDay++;
			if(startDate.getMm()==endDate.getMm())
				return endDate.getDd()-startDate.getDd();
			else
				return yearMonths[startDate.getMm()]-startDate.getDd()+endDate.getDd()+bonusDay;
		}
		
		private static int RemainingMonthsSameYear(MyDate startDate,MyDate endDate)
		{
			if(endDate.getMm()-startDate.getMm()>=2)
			{
			int monthDays=0;
			int bonusDay=0;
			for(int index=startDate.getMm()+1;index<endDate.getMm();index++)
			{
				if(startDate.getYyyy()%4==0)
				{
				if(index==2)
					bonusDay++;
				}
				monthDays+=yearMonths[index];
			}
			return monthDays+bonusDay;
			}
			else
			{
				return 0;
			}
		}
		
		private static boolean isYearLeap(int year)
		{
	        boolean leap = false;
	        if(year % 4 == 0)
	  {
	      if( year % 100 == 0)
	      {
	          if ( year % 400 == 0)
	              leap = true;
	          else
	              leap = false;
	      }
	      else
	          leap = true;
	  }
	  else
	      leap = false;
	  return leap;

		}
		
		private static long remainingMonthsDifferentYears(MyDate startDate, MyDate endDate)
		{
			int startYear=startDate.getYyyy();
			int endYear=endDate.getYyyy();
			int monthDaysStart=0;
			int monthDaysEnd=0;
			int bonusDay=0;
			if(isYearLeap(startYear)||isYearLeap(endYear))
			{
				if(startDate.getMm()<1)
					bonusDay++;
				if(endDate.getMm()>2)
					bonusDay++;
			}
			for(int index=startDate.getMm()+1;index<=12;index++)
			{
				monthDaysStart+=yearMonths[index];
			}
			for(int index=1;index<endDate.getMm();index++)
			{
				monthDaysEnd+=yearMonths[index];
			}
			
			return monthDaysStart+monthDaysEnd+bonusDay;
		}
		
		public static long intermYearDays(MyDate startDate, MyDate endDate)
		{
			int startYear=startDate.getYyyy();
			int endYear=endDate.getYyyy();
			int daysInAYear=0;
			int totalDays = 0;
			for(int index=startYear+1;index<endYear;index++)
			{
				if(isYearLeap(index))
					daysInAYear=366;
				else
					daysInAYear=365;
				totalDays+=daysInAYear;
			}
			return totalDays;
		}
	}


	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*static int array []= {	0,31,28,31,30,31,30,31,31,30,31,30,31};
			
	

	public static int getDateDifference(MyDate startDate,MyDate endDate)
	{  
		if(samedate(startDate, endDate)&&samemonth(startDate, endDate)&&sameyear(startDate, endDate))
			
		{
			return 0;
			
		}
		
		else if(samemonth(startDate, endDate)&&sameyear(startDate, endDate))
		{  
			return endDate.getDd()-startDate.getDd();
		}
		
		
		
		else if(sameyear(startDate, endDate)&&!samemonth(startDate, endDate))
		{
			return remainingdaysinmonth(startDate, endDate)+interveningmonthdays(startDate, endDate)+daysleft(startDate, endDate);
		}
		
		else if(!sameyear(startDate, endDate))
		{
			return remainingdaysinmonth(startDate, endDate)+remainingdaysinyear(startDate, endDate)+interveningyears(startDate, endDate)+daysleftinyear(startDate, endDate)+daysleft(startDate,endDate);
		}
		
		
		else if(samedate(startDate, endDate)&&sameyear(startDate, endDate))
		{
			return 
		}
		
		return 0;
		}	
		
		

	
	
	
	
	private static int daysleftinyear(MyDate startDate, MyDate endDate) {
		int sum=0;
		for(int i=01;i<endDate.getMm();i++)
		{  
			if(i==02)
			{
				sum=sum+29;
			}
			sum+=array[i];
		}
		return sum;
	}
		








	private static int interveningyears(MyDate startDate, MyDate endDate) {
		int sum=0;
		for(int i=startDate.getYyyy()+1;i<endDate.getYyyy();i++)
		
		if(isLeapYear(i))
		{
		return sum+=366;
		}
		
		return sum+=365;
				
	}

private static boolean isLeapYear(int year)
	{
        boolean leap = false;
        if(year % 4 == 0)
  {
      if( year % 100 == 0)
      {
          if ( year % 400 == 0)
              leap = true;
          else
              leap = false;
      }
      else
          leap = true;
  }
  else
      leap = false;
  return leap;

	} 
		 







	private static int remainingdaysinyear(MyDate startDate, MyDate endDate) {
		int sum=0;
		for(int i=startDate.getMm()+1;i<12;i++)
		{  
			if(i==02)
			{
				sum=sum+1;
			}
			sum+=array[i];
		}
		return sum;
	}
		
	






	private static int daysleft(MyDate startDate, MyDate endDate) {
		
		return endDate.getDd();
	}


	private static int interveningmonthdays(MyDate startDate, MyDate endDate) {
		int sum =0;
		for(int i= startDate.getMm()+1; i<endDate.getMm();i++)
		{
			 sum +=array[i];
		}
		
		return sum;
	}


	private static int remainingdaysinmonth(MyDate startDate, MyDate endDate) {
		if((startDate.getMm()==04)||(startDate.getMm()==06)||(startDate.getMm()==9)||(startDate.getMm()==11))
		
	    return 30-startDate.getDd();
	else if (startDate.getMm()==02)
		return 28-startDate.getDd();
	
	else
		return 31-startDate.getDd();
		
	}
	
	
	
	private static boolean sameyear(MyDate startDate, MyDate endDate) {
		if(endDate.getYyyy()==startDate.getYyyy())
			return true;
		return false;
	}



private static boolean samemonth(MyDate startDate, MyDate endDate) {
	if(endDate.getMm()==startDate.getMm())
		return true;
	
		return false;
	}


private static boolean samedate(MyDate startDate,MyDate endDate)
{
	if(endDate.getDd()==startDate.getDd())
		return true;
return false;
}
		
}	*\	
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		/*int a= (30-startDate.getDd())+endDate.getDd();
		int b= (28-startDate.getDd())+endDate.getDd();
		int c= (31-startDate.getDd())+endDate.getDd();
		if(startDate==endDate)
			return 0;
		
		else if (endDate.getYyyy()==startDate.getYyyy()&&endDate.getMm()==startDate.getMm())
				
			return	endDate.getDd()-startDate.getDd();
	   
		
		else if (endDate.getYyyy()==startDate.getYyyy())
		{
			if((endDate.getMm()-startDate.getMm())==1) {
			if((startDate.getMm()==04)||(startDate.getMm()==06)||(startDate.getMm()==9)||(startDate.getMm()==11))
				
				
				
				return a;
			
			else if (startDate.getMm()==02)
				return b;
			
			else
				return c;
		}
		}
		
		else */
			
			
			
				
	


